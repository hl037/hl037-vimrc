
= GRAMMALECTE =

Grammar checker
By Olivier R.

Website: http://grammalecte.net

License: GPL 3 -- http://www.gnu.org/copyleft/gpl.html

Grammalecte is a fork of Lightproof
    from László Németh (nemeth /at/ numbertext /dot/ org)
    http://cgit.freedesktop.org/libreoffice/lightproof/

Required : Python 3.3
